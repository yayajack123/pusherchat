<?php
$success  = "";
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "messages";
    $conn = new mysqli($servername, $username, $password, $dbname);