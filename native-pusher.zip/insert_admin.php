<?php
    include_once 'config.php';
    $success  = "";
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "messages";
    if(isset($_POST['id_group']))
    {  
        $id_group  = $_POST['id_group'];
        $new_admin = $_POST['user'];
        
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        $detail = "INSERT INTO `tb_moderasi` (`id_group`,`id_user`,`is_admin`)
        VALUES ($id_group,$new_admin,'1')";
        if (mysqli_query($conn, $detail)){
            echo 'success';
            header("Location: index.php");
               
        } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
?> 